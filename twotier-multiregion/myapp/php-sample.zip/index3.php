<?
$myvalue="9";

if ($_SERVER['REQUEST_METHOD'] === 'POST')
{
  $myvalue = $_POST['myvalue'];
}
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Distributed Application Test</title>
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lobster+Two" type="text/css">
	<link rel="icon" href="https://awsmedia.s3.amazonaws.com/favicon.ico" type="image/ico" >
	<link rel="shortcut icon" href="https://awsmedia.s3.amazonaws.com/favicon.ico" type="image/ico" >
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	<link rel="stylesheet" href="/styles.css" type="text/css">
</head>
<body>
	<section class="readout">
		<p>This page ran from a server in AZ <INSERT AZ> within region <INSERT REGION></p>
		<p>When it ran, it looked up the following data in the local MYSQL slave db...</p>
		<p>	INSERT SLAVE DATA HERE</p>
		<p>	Last Update Timestamp: 2014-07-19 00:00:00</p>
		<p>	Last Update by Server: <?= $_SERVER['SERVER_NAME']; ?></p>
		<p>		in AZ: <AZ GOES HERE></p>
		<p>		in REGION: <Region goes here></p>
		<p>	Value in last update: <VALUE GOES HERE></p>
		<p>
			<form action="index3.php" method="post">
			Value: <input type="text" name="myvalue" value="<?= $myvalue; ?>"><br>
			<input type="submit">
			</form>
		</p>
<?php
    while (list($var, $val) = each($_SERVER)) {
      print "<p> $var is $val </p>";
    }
?> 
	</section>

</body>
</html>
